import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/common_widgets.dart';
import '../widgets/animated_background.dart';
import '../widgets/confidence_score_widget.dart';

class AllBenefitsPage extends StatefulWidget {
  final Map<String, dynamic> aiResponse;

  const AllBenefitsPage({
    super.key,
    required this.aiResponse,
  });

  @override
  State<AllBenefitsPage> createState() => _AllBenefitsPageState();
}

class _AllBenefitsPageState extends State<AllBenefitsPage> {
  List<Map<String, dynamic>> get _retrievedBenefits {
    try {
      final benefits = widget.aiResponse['retrieved_benefits'];
      if (benefits is List && benefits.isNotEmpty) {
        return benefits.map((benefit) {
          if (benefit is Map<String, dynamic>) {
            return {
              'benefit_name': benefit['benefit_name']?.toString() ?? 'Benefit',
              'description': benefit['description']?.toString() ?? '',
              'source': benefit['source']?.toString() ?? '',
              'relevance_score': benefit['relevance_score'] ?? 0.0,
            };
          }
          return {
            'benefit_name': 'Benefit',
            'description': '',
            'source': '',
            'relevance_score': 0.0,
          };
        }).toList();
      }
      return [];
    } catch (e) {
      return [];
    }
  }

  IconData _getBenefitIcon(String benefitName) {
    final lower = benefitName.toLowerCase();
    if (lower.contains('cash')) return Icons.account_balance_wallet_rounded;
    if (lower.contains('travel') || lower.contains('flight'))
      return Icons.flight_takeoff_rounded;
    if (lower.contains('lounge')) return Icons.airline_seat_flat_rounded;
    if (lower.contains('fuel') || lower.contains('gas'))
      return Icons.local_gas_station_rounded;
    if (lower.contains('reward') || lower.contains('point'))
      return Icons.stars_rounded;
    if (lower.contains('dining') || lower.contains('food'))
      return Icons.restaurant_rounded;
    if (lower.contains('movie') || lower.contains('cinema'))
      return Icons.movie_rounded;
    if (lower.contains('shopping') || lower.contains('shop'))
      return Icons.shopping_bag_rounded;
    if (lower.contains('payment') || lower.contains('wallet') || lower.contains('upi'))
      return Icons.payment_rounded;
    if (lower.contains('insurance')) return Icons.security_rounded;
    if (lower.contains('golf')) return Icons.golf_course_rounded;
    return Icons.card_giftcard_rounded;
  }

  Color _getCategoryColor(int index) {
    final colors = [
      AppTheme.primaryBlue,
      AppTheme.accentTeal,
      const Color(0xFF7C4DFF),
      const Color(0xFFFF6F00),
      const Color(0xFF00C853),
      const Color(0xFFD32F2F),
    ];
    return colors[index % colors.length];
  }

  @override
  Widget build(BuildContext context) {
    final benefits = _retrievedBenefits;
    final hasBenefits = benefits.isNotEmpty;

    return Scaffold(
      body: AnimatedBackground(
        child: SafeArea(
          child: Column(
            children: [
              // AppBar
              Padding(
                padding: const EdgeInsets.all(AppTheme.spacingM),
                child: Row(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.arrow_back),
                      onPressed: () => Navigator.pop(context),
                    ),
                    const Expanded(
                      child: Text(
                        'Retrieved Benefits',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    const SizedBox(width: 48),
                  ],
                ),
              ),

              // Header Stats
              if (hasBenefits)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: AppTheme.spacingL),
                  child: FadeInWidget(
                    delay: const Duration(milliseconds: 100),
                    child: Container(
                      padding: const EdgeInsets.all(AppTheme.spacingL),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            AppTheme.primaryBlue.withOpacity(0.1),
                            AppTheme.accentTeal.withOpacity(0.1),
                          ],
                        ),
                        borderRadius: BorderRadius.circular(AppTheme.radiusL),
                        border: Border.all(
                          color: AppTheme.primaryBlue.withOpacity(0.2),
                        ),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          _buildStatItem(
                            Icons.search_rounded,
                            '${benefits.length}',
                            'Benefits Found',
                          ),
                          Container(
                            width: 1,
                            height: 40,
                            color: AppTheme.primaryBlue.withOpacity(0.2),
                          ),
                          _buildStatItem(
                            Icons.auto_awesome_rounded,
                            'AI',
                            'Powered',
                          ),
                        ],
                      ),
                    ),
                  ),
                ),

              const SizedBox(height: AppTheme.spacingL),

              // Benefits List
              if (hasBenefits)
                Expanded(
                  child: ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: AppTheme.spacingL),
                    itemCount: benefits.length,
                    itemBuilder: (context, index) {
                      final benefit = benefits[index];
                      final relevanceScore = benefit['relevance_score'] as double? ?? 0.0;

                      return FadeInWidget(
                        delay: Duration(milliseconds: 100 + (index * 80)),
                        child: Container(
                          margin: const EdgeInsets.only(bottom: AppTheme.spacingM),
                          child: Card(
                            elevation: 2,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(AppTheme.radiusL),
                              side: BorderSide(
                                color: _getCategoryColor(index).withOpacity(0.2),
                                width: 1.5,
                              ),
                            ),
                            child: InkWell(
                              onTap: () {
                                _showBenefitDetails(context, benefit);
                              },
                              borderRadius: BorderRadius.circular(AppTheme.radiusL),
                              child: Padding(
                                padding: const EdgeInsets.all(AppTheme.spacingL),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Container(
                                          padding: const EdgeInsets.all(12),
                                          decoration: BoxDecoration(
                                            color: _getCategoryColor(index).withOpacity(0.1),
                                            borderRadius: BorderRadius.circular(12),
                                          ),
                                          child: Icon(
                                            _getBenefitIcon(benefit['benefit_name'] ?? ''),
                                            color: _getCategoryColor(index),
                                            size: 24,
                                          ),
                                        ),
                                        const SizedBox(width: AppTheme.spacingM),
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                benefit['benefit_name'] ?? 'Benefit',
                                                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                                  fontWeight: FontWeight.bold,
                                                ),
                                                maxLines: 2,
                                                overflow: TextOverflow.ellipsis,
                                              ),
                                              if (relevanceScore > 0) ...[
                                                const SizedBox(height: 4),
                                                CompactConfidenceIndicator(score: relevanceScore),
                                              ],
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                    if (benefit['description']?.toString().isNotEmpty ?? false) ...[
                                      const SizedBox(height: AppTheme.spacingM),
                                      Text(
                                        benefit['description'] ?? '',
                                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                          height: 1.5,
                                          color: AppTheme.textSecondary,
                                        ),
                                        maxLines: 3,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ],
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                )
              else
                Expanded(
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.inbox_rounded,
                          size: 80,
                          color: Colors.grey.shade300,
                        ),
                        const SizedBox(height: AppTheme.spacingL),
                        Text(
                          'No Benefits Retrieved',
                          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                            color: AppTheme.textSecondary,
                          ),
                        ),
                        const SizedBox(height: AppTheme.spacingS),
                        Text(
                          'Try analyzing your card again',
                          style: Theme.of(context).textTheme.bodyMedium,
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatItem(IconData icon, String value, String label) {
    return Column(
      children: [
        Icon(icon, color: AppTheme.primaryBlue, size: 28),
        const SizedBox(height: 4),
        Text(
          value,
          style: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: AppTheme.primaryBlue,
          ),
        ),
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: AppTheme.textSecondary,
          ),
        ),
      ],
    );
  }

  void _showBenefitDetails(BuildContext context, Map<String, dynamic> benefit) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * 0.75,
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(AppTheme.radiusXL)),
        ),
        child: Column(
          children: [
            // Handle bar
            Container(
              margin: const EdgeInsets.symmetric(vertical: 12),
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.grey.shade300,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(AppTheme.spacingXL),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            gradient: AppTheme.primaryGradient,
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Icon(
                            _getBenefitIcon(benefit['benefit_name'] ?? ''),
                            color: Colors.white,
                            size: 32,
                          ),
                        ),
                        const SizedBox(width: AppTheme.spacingL),
                        Expanded(
                          child: Text(
                            benefit['benefit_name'] ?? 'Benefit',
                            style: Theme.of(context).textTheme.headlineMedium,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: AppTheme.spacingXL),
                    
                    if (benefit['description']?.toString().isNotEmpty ?? false) ...[
                      Text(
                        'Description',
                        style: Theme.of(context).textTheme.titleLarge,
                      ),
                      const SizedBox(height: AppTheme.spacingM),
                      Text(
                        benefit['description'] ?? '',
                        style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                          height: 1.6,
                        ),
                      ),
                      const SizedBox(height: AppTheme.spacingL),
                    ],
                    
                    if (benefit['source']?.toString().isNotEmpty ?? false) ...[
                      const Divider(),
                      const SizedBox(height: AppTheme.spacingM),
                      Row(
                        children: [
                          Icon(
                            Icons.link_rounded,
                            size: 16,
                            color: AppTheme.textSecondary,
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              'Source',
                              style: Theme.of(context).textTheme.bodySmall,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(
                        benefit['source'] ?? '',
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: AppTheme.accentTeal,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

                        iconColor: benefit['color'],
                        onTap: () {
                          _showBenefitDetails(context, benefit);
                        },
                      ),
                    );
                  },
                ),
              ),

              // Bottom Action
              Container(
                padding: const EdgeInsets.all(AppTheme.spacingL),
                decoration: BoxDecoration(
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 10,
                      offset: const Offset(0, -2),
                    ),
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.check_circle,
                          color: AppTheme.success,
                          size: 20,
                        ),
                        const SizedBox(width: AppTheme.spacingS),
                        Text(
                          '${_filteredBenefits.length} benefits available',
                          style:
                              Theme.of(context).textTheme.titleMedium?.copyWith(
                                    color: AppTheme.success,
                                  ),
                        ),
                      ],
                    ),
                    const SizedBox(height: AppTheme.spacingM),
                    PrimaryButton(
                      text: 'Learn How It Works',
                      icon: Icons.play_circle_outline,
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const HowItWorksPage(),
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showBenefitDetails(BuildContext context, Map<String, dynamic> benefit) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * 0.6,
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: Column(
          children: [
            const SizedBox(height: AppTheme.spacingM),
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.grey.shade300,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(AppTheme.spacingL),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Container(
                        padding: const EdgeInsets.all(AppTheme.spacingL),
                        decoration: BoxDecoration(
                          color: (benefit['color'] as Color).withOpacity(0.1),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          benefit['icon'],
                          size: 48,
                          color: benefit['color'],
                        ),
                      ),
                    ),
                    const SizedBox(height: AppTheme.spacingL),
                    Text(
                      benefit['title'],
                      style: Theme.of(context).textTheme.displaySmall,
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: AppTheme.spacingM),
                    Text(
                      benefit['description'],
                      style: Theme.of(context).textTheme.bodyLarge,
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: AppTheme.spacingXL),
                    _buildDetailSection(
                      context,
                      'How to Use',
                      [
                        'Present your card at partner locations',
                        'Benefits automatically applied at checkout',
                        'Track usage in your card statement',
                      ],
                    ),
                    const SizedBox(height: AppTheme.spacingL),
                    _buildDetailSection(
                      context,
                      'Terms & Conditions',
                      [
                        'Valid on primary cardholder account',
                        'Subject to merchant participation',
                        'Cannot be combined with other offers',
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailSection(
    BuildContext context,
    String title,
    List<String> items,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: Theme.of(context).textTheme.titleLarge,
        ),
        const SizedBox(height: AppTheme.spacingM),
        ...items.map(
          (item) => Padding(
            padding: const EdgeInsets.only(bottom: AppTheme.spacingS),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(
                  Icons.check_circle,
                  color: AppTheme.success,
                  size: 20,
                ),
                const SizedBox(width: AppTheme.spacingS),
                Expanded(
                  child: Text(
                    item,
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
