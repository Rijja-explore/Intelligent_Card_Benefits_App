import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/common_widgets.dart';
import '../widgets/animated_background.dart';

class DisclaimerPage extends StatelessWidget {
  const DisclaimerPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AnimatedBackground(
        child: SafeArea(
          child: Column(
            children: [
              // AppBar
              Padding(
                padding: const EdgeInsets.all(AppTheme.spacingM),
                child: Row(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.arrow_back),
                      onPressed: () => Navigator.pop(context),
                    ),
                    const Expanded(
                      child: Text(
                        'Disclaimer',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    const SizedBox(width: 48),
                  ],
                ),
              ),

              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(AppTheme.spacingL),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Icon Header
                      FadeInWidget(
                        delay: const Duration(milliseconds: 100),
                        child: Center(
                          child: Container(
                            padding: const EdgeInsets.all(AppTheme.spacingXL),
                            decoration: BoxDecoration(
                              color: AppTheme.accentTeal.withOpacity(0.1),
                              shape: BoxShape.circle,
                            ),
                            child: Icon(
                              Icons.info_outline,
                              size: 64,
                              color: AppTheme.accentTeal,
                            ),
                          ),
                        ),
                      ),

                      const SizedBox(height: AppTheme.spacingXL),

                      // Main Disclaimer
                      FadeInWidget(
                        delay: const Duration(milliseconds: 200),
                        child: Card(
                          child: Padding(
                            padding: const EdgeInsets.all(AppTheme.spacingL),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Icon(
                                      Icons.warning_amber_rounded,
                                      color: AppTheme.warning,
                                      size: 28,
                                    ),
                                    const SizedBox(width: AppTheme.spacingM),
                                    Text(
                                      'Important Notice',
                                      style: Theme.of(context)
                                          .textTheme
                                          .headlineMedium,
                                    ),
                                  ],
                                ),
                                const SizedBox(height: AppTheme.spacingL),
                                Text(
                                  'This application is designed for educational and awareness purposes only.',
                                  style: Theme.of(context)
                                      .textTheme
                                      .bodyLarge
                                      ?.copyWith(
                                        fontWeight: FontWeight.w600,
                                      ),
                                ),
                                const SizedBox(height: AppTheme.spacingM),
                                Text(
                                  'No real credit card data is processed, validated, or stored. All insights and recommendations are AI-generated based on publicly available benefit information.',
                                  style: Theme.of(context).textTheme.bodyLarge,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),

                      const SizedBox(height: AppTheme.spacingL),

                      // Privacy & Security
                      FadeInWidget(
                        delay: const Duration(milliseconds: 300),
                        child: _buildSection(
                          context,
                          'Privacy & Security',
                          Icons.shield_outlined,
                          AppTheme.success,
                          [
                            'No real card numbers are validated or verified',
                            'All data processing happens in real-time',
                            'No personal information is stored in databases',
                            'Card details are masked for demonstration only',
                            'Session data is cleared immediately after use',
                          ],
                        ),
                      ),

                      const SizedBox(height: AppTheme.spacingL),

                      // AI-Generated Content
                      FadeInWidget(
                        delay: const Duration(milliseconds: 400),
                        child: _buildSection(
                          context,
                          'AI-Generated Content',
                          Icons.auto_awesome,
                          AppTheme.accentTeal,
                          [
                            'Recommendations are generated by Gemini AI',
                            'Results are based on RAG with curated data',
                            'AI insights may not reflect actual card benefits',
                            'Always verify with your bank for accurate details',
                            'System is designed for demonstration purposes',
                          ],
                        ),
                      ),

                      const SizedBox(height: AppTheme.spacingL),

                      // Compliance
                      FadeInWidget(
                        delay: const Duration(milliseconds: 500),
                        child: _buildSection(
                          context,
                          'Academic Compliance',
                          Icons.school,
                          AppTheme.primaryBlue,
                          [
                            'Built for hackathons and academic projects',
                            'Not intended for commercial use',
                            'Follows privacy-first design principles',
                            'No financial transactions or validations',
                            'Safe for demonstration and evaluation',
                          ],
                        ),
                      ),

                      const SizedBox(height: AppTheme.spacingXL),

                      // Contact Card
                      FadeInWidget(
                        delay: const Duration(milliseconds: 600),
                        child: GradientCard(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  const Icon(
                                    Icons.contact_support,
                                    color: Colors.white,
                                    size: 28,
                                  ),
                                  const SizedBox(width: AppTheme.spacingM),
                                  Text(
                                    'Need Help?',
                                    style: Theme.of(context)
                                        .textTheme
                                        .headlineMedium
                                        ?.copyWith(color: Colors.white),
                                  ),
                                ],
                              ),
                              const SizedBox(height: AppTheme.spacingM),
                              const Text(
                                'For questions about this project or to report issues, please contact the development team through your academic institution.',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 14,
                                  height: 1.5,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),

                      const SizedBox(height: AppTheme.spacingXL),

                      // Acknowledgment
                      FadeInWidget(
                        delay: const Duration(milliseconds: 700),
                        child: Container(
                          padding: const EdgeInsets.all(AppTheme.spacingL),
                          decoration: BoxDecoration(
                            color: AppTheme.primaryBlue.withOpacity(0.05),
                            borderRadius:
                                BorderRadius.circular(AppTheme.radiusL),
                            border: Border.all(
                              color: AppTheme.primaryBlue.withOpacity(0.2),
                              width: 1,
                            ),
                          ),
                          child: Column(
                            children: [
                              Icon(
                                Icons.check_circle,
                                color: AppTheme.success,
                                size: 32,
                              ),
                              const SizedBox(height: AppTheme.spacingM),
                              Text(
                                'By using this application, you acknowledge that you understand its educational purpose and limitations.',
                                style: Theme.of(context)
                                    .textTheme
                                    .bodyMedium
                                    ?.copyWith(
                                      fontWeight: FontWeight.w500,
                                    ),
                                textAlign: TextAlign.center,
                              ),
                            ],
                          ),
                        ),
                      ),

                      const SizedBox(height: AppTheme.spacingXL),

                      // Back Button
                      FadeInWidget(
                        delay: const Duration(milliseconds: 800),
                        child: PrimaryButton(
                          text: 'I Understand',
                          icon: Icons.check,
                          onPressed: () => Navigator.pop(context),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSection(
    BuildContext context,
    String title,
    IconData icon,
    Color color,
    List<String> points,
  ) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(AppTheme.spacingL),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(AppTheme.spacingS),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(AppTheme.radiusM),
                  ),
                  child: Icon(icon, color: color, size: 24),
                ),
                const SizedBox(width: AppTheme.spacingM),
                Text(
                  title,
                  style: Theme.of(context).textTheme.titleLarge,
                ),
              ],
            ),
            const SizedBox(height: AppTheme.spacingL),
            ...points.map(
              (point) => Padding(
                padding: const EdgeInsets.only(bottom: AppTheme.spacingM),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(
                      Icons.check_circle,
                      color: color,
                      size: 20,
                    ),
                    const SizedBox(width: AppTheme.spacingM),
                    Expanded(
                      child: Text(
                        point,
                        style: Theme.of(context).textTheme.bodyMedium,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
