import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../theme/app_theme.dart';
import '../widgets/common_widgets.dart';
import '../widgets/animated_background.dart';
import '../api_config.dart';
import 'ai_summary_page.dart';

class CardInputPage extends StatefulWidget {
  const CardInputPage({super.key});

  @override
  State<CardInputPage> createState() => _CardInputPageState();
}

class _CardInputPageState extends State<CardInputPage> {
  final _formKey = GlobalKey<FormState>();
  final _cardController = TextEditingController();
  final _locationController = TextEditingController();

  String _userType = 'Student';
  String _language = 'English';
  bool _isLoading = false;

  @override
  void dispose() {
    _cardController.dispose();
    _locationController.dispose();
    super.dispose();
  }

  String _formatCardNumber(String value) {
    value = value.replaceAll(' ', '');
    String formatted = '';
    for (int i = 0; i < value.length; i++) {
      if (i > 0 && i % 4 == 0) {
        formatted += ' ';
      }
      formatted += value[i];
    }
    return formatted;
  }

  Future<void> _analyzeBenefits() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    try {
      final response = await http.post(
        Uri.parse(ApiConfig.genaiUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'user_context': {
            'user_type': _userType,
            'location': _locationController.text.trim(),
          },
          'language': _language,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        if (mounted) {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => AISummaryPage(
                aiResponse: data,
                userContext: {
                  'user_type': _userType,
                  'location': _locationController.text.trim(),
                  'card_number': _cardController.text,
                  'language': _language,
                },
              ),
            ),
          );
        }
      } else {
        _showError('Failed to analyze benefits. Please try again.');
      }
    } catch (e) {
      _showError('Network error. Please check your connection.');
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: AppTheme.error,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AnimatedBackground(
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(AppTheme.spacingL),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: AppTheme.spacingXL),

                  // Header
                  FadeInWidget(
                    delay: const Duration(milliseconds: 100),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Discover Your',
                          style: Theme.of(context).textTheme.displayMedium,
                        ),
                        ShaderMask(
                          shaderCallback: (bounds) =>
                              AppTheme.primaryGradient.createShader(bounds),
                          child: Text(
                            'Card Benefits',
                            style: Theme.of(context)
                                .textTheme
                                .displayLarge
                                ?.copyWith(
                                  color: Colors.white,
                                ),
                          ),
                        ),
                        const SizedBox(height: AppTheme.spacingS),
                        Text(
                          'Enter your details to get AI-powered personalized recommendations',
                          style:
                              Theme.of(context).textTheme.bodyLarge?.copyWith(
                                    color: AppTheme.textSecondary,
                                  ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: AppTheme.spacingXXL),

                  // Card Number Input
                  FadeInWidget(
                    delay: const Duration(milliseconds: 200),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Card Number',
                          style: Theme.of(context).textTheme.titleMedium,
                        ),
                        const SizedBox(height: AppTheme.spacingS),
                        TextFormField(
                          controller: _cardController,
                          decoration: const InputDecoration(
                            hintText: 'XXXX XXXX XXXX 1234',
                            prefixIcon: Icon(Icons.credit_card),
                          ),
                          keyboardType: TextInputType.number,
                          inputFormatters: [
                            FilteringTextInputFormatter.digitsOnly,
                            LengthLimitingTextInputFormatter(16),
                          ],
                          onChanged: (value) {
                            final formatted = _formatCardNumber(value);
                            if (formatted != value) {
                              _cardController.value = TextEditingValue(
                                text: formatted,
                                selection: TextSelection.collapsed(
                                  offset: formatted.length,
                                ),
                              );
                            }
                          },
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter a card number';
                            }
                            if (value.replaceAll(' ', '').length < 13) {
                              return 'Card number must be at least 13 digits';
                            }
                            return null;
                          },
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: AppTheme.spacingL),

                  // User Type Selector
                  FadeInWidget(
                    delay: const Duration(milliseconds: 300),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'I am a',
                          style: Theme.of(context).textTheme.titleMedium,
                        ),
                        const SizedBox(height: AppTheme.spacingS),
                        Row(
                          children: [
                            Expanded(
                              child: _buildOptionCard(
                                'Student',
                                Icons.school,
                                _userType == 'Student',
                                () => setState(() => _userType = 'Student'),
                              ),
                            ),
                            const SizedBox(width: AppTheme.spacingM),
                            Expanded(
                              child: _buildOptionCard(
                                'Professional',
                                Icons.work,
                                _userType == 'Professional',
                                () =>
                                    setState(() => _userType = 'Professional'),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: AppTheme.spacingL),

                  // Location Input
                  FadeInWidget(
                    delay: const Duration(milliseconds: 400),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Location',
                          style: Theme.of(context).textTheme.titleMedium,
                        ),
                        const SizedBox(height: AppTheme.spacingS),
                        TextFormField(
                          controller: _locationController,
                          decoration: const InputDecoration(
                            hintText: 'e.g., Chennai',
                            prefixIcon: Icon(Icons.location_on),
                          ),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter your location';
                            }
                            return null;
                          },
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: AppTheme.spacingL),

                  // Language Selector
                  FadeInWidget(
                    delay: const Duration(milliseconds: 500),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Preferred Language',
                          style: Theme.of(context).textTheme.titleMedium,
                        ),
                        const SizedBox(height: AppTheme.spacingS),
                        Row(
                          children: [
                            Expanded(
                              child: _buildOptionCard(
                                'English',
                                Icons.language,
                                _language == 'English',
                                () => setState(() => _language = 'English'),
                              ),
                            ),
                            const SizedBox(width: AppTheme.spacingM),
                            Expanded(
                              child: _buildOptionCard(
                                'Tamil',
                                Icons.translate,
                                _language == 'Tamil',
                                () => setState(() => _language = 'Tamil'),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: AppTheme.spacingXXL),

                  // Submit Button
                  FadeInWidget(
                    delay: const Duration(milliseconds: 600),
                    child: PrimaryButton(
                      text: 'Analyze My Benefits',
                      icon: Icons.auto_awesome,
                      onPressed: _analyzeBenefits,
                      isLoading: _isLoading,
                    ),
                  ),

                  const SizedBox(height: AppTheme.spacingL),

                  // Privacy Note
                  FadeInWidget(
                    delay: const Duration(milliseconds: 700),
                    child: Container(
                      padding: const EdgeInsets.all(AppTheme.spacingM),
                      decoration: BoxDecoration(
                        color: AppTheme.accentTeal.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(AppTheme.radiusL),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            Icons.lock,
                            color: AppTheme.accentTeal,
                            size: 20,
                          ),
                          const SizedBox(width: AppTheme.spacingM),
                          Expanded(
                            child: Text(
                              'Your data is not stored. This is an awareness-only system.',
                              style: Theme.of(context)
                                  .textTheme
                                  .bodyMedium
                                  ?.copyWith(
                                    color: AppTheme.textSecondary,
                                  ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildOptionCard(
    String label,
    IconData icon,
    bool isSelected,
    VoidCallback onTap,
  ) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: AppTheme.normalAnimation,
        padding: const EdgeInsets.all(AppTheme.spacingM),
        decoration: BoxDecoration(
          gradient: isSelected ? AppTheme.primaryGradient : null,
          color: isSelected ? null : Colors.white,
          borderRadius: BorderRadius.circular(AppTheme.radiusL),
          border: Border.all(
            color: isSelected
                ? Colors.transparent
                : AppTheme.primaryBlue.withOpacity(0.2),
            width: 1.5,
          ),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: AppTheme.primaryBlue.withOpacity(0.3),
                    blurRadius: 12,
                    offset: const Offset(0, 4),
                  ),
                ]
              : null,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              color: isSelected ? Colors.white : AppTheme.primaryBlue,
              size: 32,
            ),
            const SizedBox(height: AppTheme.spacingS),
            Text(
              label,
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    color: isSelected ? Colors.white : AppTheme.primaryBlue,
                  ),
            ),
          ],
        ),
      ),
    );
  }
}
