import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/common_widgets.dart';
import '../widgets/animated_background.dart';
import '../widgets/confidence_score_widget.dart';
import 'recommended_benefit_page.dart';
import 'all_benefits_page.dart';

class AISummaryPage extends StatefulWidget {
  final Map<String, dynamic> aiResponse;
  final Map<String, dynamic> userContext;

  const AISummaryPage({
    super.key,
    required this.aiResponse,
    required this.userContext,
  });

  @override
  State<AISummaryPage> createState() => _AISummaryPageState();
}

class _AISummaryPageState extends State<AISummaryPage>
    with TickerProviderStateMixin {
  late AnimationController _fadeController;
  late AnimationController _slideController;
  
  double get _confidenceScore {
    try {
      final score = widget.aiResponse['confidence_score'];
      if (score is num) return score.toDouble();
      return 0.75; // Default fallback
    } catch (e) {
      return 0.75;
    }
  }

  String get _summary => widget.aiResponse['summary']?.toString() ?? 
      'AI analysis complete. View recommendations below.';

  String get _recommendedBenefit => widget.aiResponse['recommended_benefit']?.toString() ?? 
      'Top Recommendation Available';

  List<String> get _reasoning {
    try {
      final reasoning = widget.aiResponse['reasoning'];
      if (reasoning is List) {
        return reasoning.map((e) => e.toString()).toList();
      }
      return ['Personalized analysis based on your profile'];
    } catch (e) {
      return ['Personalized analysis based on your profile'];
    }
  }

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    _slideController = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );
    
    _fadeController.forward();
    _slideController.forward();
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _slideController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AnimatedBackground(
        child: SafeArea(
          child: Column(
            children: [
              // AppBar
              Padding(
                padding: const EdgeInsets.all(AppTheme.spacingM),
                child: Row(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.arrow_back),
                      onPressed: () => Navigator.pop(context),
                    ),
                    const Expanded(
                      child: Text(
                        'AI Analysis',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    const SizedBox(width: 48),
                  ],
                ),
              ),

              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(AppTheme.spacingL),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      // Confidence Score Header
                      FadeInWidget(
                        delay: const Duration(milliseconds: 100),
                        child: Center(
                          child: Column(
                            children: [
                              ConfidenceScoreWidget(
                                score: _confidenceScore,
                                size: 140,
                                showLabel: true,
                              ),
                              const SizedBox(height: AppTheme.spacingL),
                              Text(
                                'Match Analysis Complete',
                                style: Theme.of(context).textTheme.displaySmall,
                                textAlign: TextAlign.center,
                              ),
                              const SizedBox(height: AppTheme.spacingS),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: AppTheme.spacingM,
                                  vertical: AppTheme.spacingS,
                                ),
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [
                                      AppTheme.accentTeal.withOpacity(0.1),
                                      AppTheme.primaryBlue.withOpacity(0.1),
                                    ],
                                  ),
                                  borderRadius: BorderRadius.circular(AppTheme.radiusM),
                                  border: Border.all(
                                    color: AppTheme.accentTeal.withOpacity(0.3),
                                  ),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: const [
                                    Icon(
                                      Icons.auto_awesome,
                                      color: AppTheme.accentTeal,
                                      size: 16,
                                    ),
                                    SizedBox(width: AppTheme.spacingS),
                                    Text(
                                      'AI-Powered Analysis',
                                      style: TextStyle(
                                        color: AppTheme.accentTeal,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 13,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),

                      const SizedBox(height: AppTheme.spacingXL),

                      // Summary Card
                      FadeInWidget(
                        delay: const Duration(milliseconds: 300),
                        child: Card(
                          child: Container(
                            width: double.infinity,
                            padding: const EdgeInsets.all(AppTheme.spacingL),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.all(AppTheme.spacingS),
                                      decoration: BoxDecoration(
                                        color: AppTheme.primaryBlue.withOpacity(0.1),
                                        borderRadius: BorderRadius.circular(AppTheme.radiusM),
                                      ),
                                      child: const Icon(
                                        Icons.insights,
                                        color: AppTheme.primaryBlue,
                                        size: 20,
                                      ),
                                    ),
                                    const SizedBox(width: AppTheme.spacingM),
                                    Text(
                                      'Summary',
                                      style: Theme.of(context).textTheme.titleLarge,
                                    ),
                                  ],
                                ),
                                const SizedBox(height: AppTheme.spacingL),
                                Text(
                                  _summary,
                                  style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                                    height: 1.6,
                                    color: AppTheme.textPrimary,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),

                      const SizedBox(height: AppTheme.spacingL),

                      // Top Recommendation Preview
                      FadeInWidget(
                        delay: const Duration(milliseconds: 400),
                        child: Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                AppTheme.primaryBlue,
                                AppTheme.primaryBlue.withOpacity(0.8),
                              ],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(AppTheme.radiusXL),
                            boxShadow: [
                              BoxShadow(
                                color: AppTheme.primaryBlue.withOpacity(0.3),
                                blurRadius: 15,
                                offset: const Offset(0, 8),
                              ),
                            ],
                          ),
                          padding: const EdgeInsets.all(AppTheme.spacingL),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: const [
                                  Icon(
                                    Icons.star_rounded,
                                    color: Colors.amber,
                                    size: 24,
                                  ),
                                  SizedBox(width: AppTheme.spacingS),
                                  Text(
                                    'Top Recommendation',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 16,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: AppTheme.spacingM),
                              Text(
                                _recommendedBenefit,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                  height: 1.3,
                                ),
                              ),
                              const SizedBox(height: AppTheme.spacingM),
                              TextButton.icon(
                                onPressed: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => RecommendedBenefitPage(
                                        aiResponse: widget.aiResponse,
                                        userContext: widget.userContext,
                                      ),
                                    ),
                                  );
                                },
                                icon: const Icon(
                                  Icons.arrow_forward_rounded,
                                  color: Colors.white,
                                ),
                                label: const Text(
                                  'View Details',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                                style: TextButton.styleFrom(
                                  backgroundColor: Colors.white.withOpacity(0.2),
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 16,
                                    vertical: 12,
                                  ),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),

                      const SizedBox(height: AppTheme.spacingL),

                      // Reasoning Cards
                      if (_reasoning.isNotEmpty)
                        FadeInWidget(
                          delay: const Duration(milliseconds: 500),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(bottom: AppTheme.spacingM),
                                child: Text(
                                  'Why This Matches You',
                                  style: Theme.of(context).textTheme.titleLarge,
                                ),
                              ),
                              ..._reasoning.asMap().entries.map((entry) {
                                final index = entry.key;
                                final reason = entry.value;
                                return FadeInWidget(
                                  delay: Duration(milliseconds: 600 + (index * 100)),
                                  child: Container(
                                    margin: const EdgeInsets.only(bottom: AppTheme.spacingM),
                                    padding: const EdgeInsets.all(AppTheme.spacingL),
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(AppTheme.radiusL),
                                      border: Border.all(
                                        color: AppTheme.accentTeal.withOpacity(0.2),
                                        width: 1.5,
                                      ),
                                      boxShadow: [
                                        BoxShadow(
                                          color: Colors.black.withOpacity(0.03),
                                          blurRadius: 8,
                                          offset: const Offset(0, 2),
                                        ),
                                      ],
                                    ),
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          width: 28,
                                          height: 28,
                                          decoration: BoxDecoration(
                                            color: AppTheme.accentTeal.withOpacity(0.1),
                                            shape: BoxShape.circle,
                                          ),
                                          child: Center(
                                            child: Text(
                                              '${index + 1}',
                                              style: const TextStyle(
                                                color: AppTheme.accentTeal,
                                                fontWeight: FontWeight.bold,
                                                fontSize: 14,
                                              ),
                                            ),
                                          ),
                                        ),
                                        const SizedBox(width: AppTheme.spacingM),
                                        Expanded(
                                          child: Text(
                                            reason,
                                            style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                                              height: 1.5,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              }).toList(),
                            ],
                          ),
                        ),

                      const SizedBox(height: AppTheme.spacingXL),

                      // Action Buttons
                      FadeInWidget(
                        delay: const Duration(milliseconds: 800),
                        child: Column(
                          children: [
                            PrimaryButton(
                              text: 'View All Benefits',
                              icon: Icons.grid_view_rounded,
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => AllBenefitsPage(
                                      aiResponse: widget.aiResponse,
                                    ),
                                  ),
                                );
                              },
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
