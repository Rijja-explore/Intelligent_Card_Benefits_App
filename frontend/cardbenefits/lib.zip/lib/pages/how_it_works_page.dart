import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/common_widgets.dart';
import '../widgets/animated_background.dart';
import 'disclaimer_page.dart';

class HowItWorksPage extends StatelessWidget {
  const HowItWorksPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AnimatedBackground(
        child: SafeArea(
          child: Column(
            children: [
              // AppBar
              Padding(
                padding: const EdgeInsets.all(AppTheme.spacingM),
                child: Row(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.arrow_back),
                      onPressed: () => Navigator.pop(context),
                    ),
                    const Expanded(
                      child: Text(
                        'How It Works',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    const SizedBox(width: 48),
                  ],
                ),
              ),

              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(AppTheme.spacingL),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Header
                      FadeInWidget(
                        delay: const Duration(milliseconds: 100),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Understanding Our',
                              style: Theme.of(context).textTheme.displayMedium,
                            ),
                            ShaderMask(
                              shaderCallback: (bounds) =>
                                  AppTheme.primaryGradient.createShader(bounds),
                              child: Text(
                                'AI System',
                                style: Theme.of(context)
                                    .textTheme
                                    .displayLarge
                                    ?.copyWith(
                                      color: Colors.white,
                                    ),
                              ),
                            ),
                            const SizedBox(height: AppTheme.spacingS),
                            Text(
                              'A transparent look at how we generate personalized benefit recommendations',
                              style: Theme.of(context)
                                  .textTheme
                                  .bodyLarge
                                  ?.copyWith(
                                    color: AppTheme.textSecondary,
                                  ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: AppTheme.spacingXXL),

                      // Process Steps
                      FadeInWidget(
                        delay: const Duration(milliseconds: 200),
                        child: const StepperItem(
                          stepNumber: 1,
                          title: 'User Input Collection',
                          description:
                              'You provide your card details, user type, location, and language preference. This helps us understand your profile and needs.',
                          icon: Icons.person_add,
                        ),
                      ),

                      FadeInWidget(
                        delay: const Duration(milliseconds: 300),
                        child: const StepperItem(
                          stepNumber: 2,
                          title: 'RAG Retrieval',
                          description:
                              'Our Retrieval-Augmented Generation system filters the benefits database to find only those relevant to your profile—no guessing, only verified data.',
                          icon: Icons.search,
                        ),
                      ),

                      FadeInWidget(
                        delay: const Duration(milliseconds: 400),
                        child: const StepperItem(
                          stepNumber: 3,
                          title: 'AI Reasoning',
                          description:
                              'Gemini LLM analyzes the retrieved benefits, considering your context to determine the most valuable options for you.',
                          icon: Icons.psychology,
                        ),
                      ),

                      FadeInWidget(
                        delay: const Duration(milliseconds: 500),
                        child: const StepperItem(
                          stepNumber: 4,
                          title: 'Personalized Output',
                          description:
                              'You receive a clear summary, highlighted recommendation, and detailed explanation in your preferred language.',
                          icon: Icons.auto_awesome,
                          isLast: true,
                        ),
                      ),

                      const SizedBox(height: AppTheme.spacingXXL),

                      // Key Features
                      FadeInWidget(
                        delay: const Duration(milliseconds: 600),
                        child: Card(
                          child: Padding(
                            padding: const EdgeInsets.all(AppTheme.spacingL),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Icon(
                                      Icons.star,
                                      color: AppTheme.accentTeal,
                                      size: 28,
                                    ),
                                    const SizedBox(width: AppTheme.spacingM),
                                    Text(
                                      'Key Features',
                                      style: Theme.of(context)
                                          .textTheme
                                          .headlineMedium,
                                    ),
                                  ],
                                ),
                                const SizedBox(height: AppTheme.spacingL),
                                _buildFeature(
                                  context,
                                  'Privacy-First',
                                  'No card data is stored. All processing is real-time and temporary.',
                                  Icons.lock,
                                  AppTheme.success,
                                ),
                                _buildFeature(
                                  context,
                                  'Grounded AI',
                                  'RAG ensures every recommendation is based on real benefit data.',
                                  Icons.verified,
                                  AppTheme.accentTeal,
                                ),
                                _buildFeature(
                                  context,
                                  'Multilingual',
                                  'Get insights in English or Tamil, with more languages coming soon.',
                                  Icons.language,
                                  AppTheme.primaryBlue,
                                ),
                                _buildFeature(
                                  context,
                                  'Real-Time',
                                  'Instant analysis powered by Gemini AI for quick results.',
                                  Icons.flash_on,
                                  AppTheme.warning,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),

                      const SizedBox(height: AppTheme.spacingXL),

                      // Technology Stack
                      FadeInWidget(
                        delay: const Duration(milliseconds: 700),
                        child: GradientCard(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  const Icon(
                                    Icons.code,
                                    color: Colors.white,
                                    size: 28,
                                  ),
                                  const SizedBox(width: AppTheme.spacingM),
                                  Text(
                                    'Technology Stack',
                                    style: Theme.of(context)
                                        .textTheme
                                        .headlineMedium
                                        ?.copyWith(color: Colors.white),
                                  ),
                                ],
                              ),
                              const SizedBox(height: AppTheme.spacingL),
                              _buildTechItem(
                                  'Frontend', 'Flutter (Material 3)'),
                              _buildTechItem('Backend', 'FastAPI (Python)'),
                              _buildTechItem('AI Model', 'Google Gemini LLM'),
                              _buildTechItem('Architecture',
                                  'RAG (Retrieval-Augmented Generation)'),
                              _buildTechItem(
                                  'Data Source', 'Curated JSON Database'),
                            ],
                          ),
                        ),
                      ),

                      const SizedBox(height: AppTheme.spacingXXL),

                      // Action Button
                      FadeInWidget(
                        delay: const Duration(milliseconds: 800),
                        child: PrimaryButton(
                          text: 'View Disclaimer',
                          icon: Icons.info_outline,
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => const DisclaimerPage(),
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFeature(
    BuildContext context,
    String title,
    String description,
    IconData icon,
    Color color,
  ) {
    return Padding(
      padding: const EdgeInsets.only(bottom: AppTheme.spacingL),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(AppTheme.spacingM),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(AppTheme.radiusM),
            ),
            child: Icon(icon, color: color, size: 24),
          ),
          const SizedBox(width: AppTheme.spacingM),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: 4),
                Text(
                  description,
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTechItem(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: AppTheme.spacingM),
      child: Row(
        children: [
          Container(
            width: 6,
            height: 6,
            decoration: const BoxDecoration(
              color: Colors.white,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: AppTheme.spacingM),
          Expanded(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  label,
                  style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 14,
                  ),
                ),
                Text(
                  value,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
