import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/common_widgets.dart';
import '../widgets/animated_background.dart';
import '../widgets/confidence_score_widget.dart';

class RecommendedBenefitPage extends StatefulWidget {
  final Map<String, dynamic> aiResponse;
  final Map<String, dynamic> userContext;

  const RecommendedBenefitPage({
    super.key,
    required this.aiResponse,
    required this.userContext,
  });

  @override
  State<RecommendedBenefitPage> createState() => _RecommendedBenefitPageState();
}

class _RecommendedBenefitPageState extends State<RecommendedBenefitPage>
    with TickerProviderStateMixin {
  late AnimationController _glowController;
  late Animation<double> _glowAnimation;

  String get _recommendedBenefit => 
      widget.aiResponse['recommended_benefit']?.toString() ?? 
      'Premium Card Benefit';

  double get _confidenceScore {
    try {
      final score = widget.aiResponse['confidence_score'];
      if (score is num) return score.toDouble();
      return 0.75;
    } catch (e) {
      return 0.75;
    }
  }

  List<String> get _reasoning {
    try {
      final reasoning = widget.aiResponse['reasoning'];
      if (reasoning is List) {
        return reasoning.map((e) => e.toString()).toList();
      }
      return ['Personalized recommendation based on your profile'];
    } catch (e) {
      return ['Personalized recommendation based on your profile'];
    }
  }

  @override
  void initState() {
    super.initState();
    _glowController = AnimationController(
      duration: const Duration(milliseconds: 2000),
      vsync: this,
    )..repeat(reverse: true);

    _glowAnimation = Tween<double>(begin: 0.7, end: 1.0).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _glowController.dispose();
    super.dispose();
  }

  IconData _getBenefitIcon() {
    final benefit = _recommendedBenefit.toLowerCase();
    if (benefit.contains('cash')) return Icons.account_balance_wallet;
    if (benefit.contains('travel') || benefit.contains('flight'))
      return Icons.flight_takeoff;
    if (benefit.contains('lounge')) return Icons.airline_seat_flat;
    if (benefit.contains('fuel')) return Icons.local_gas_station;
    if (benefit.contains('reward') || benefit.contains('point'))
      return Icons.stars;
    if (benefit.contains('dining')) return Icons.restaurant;
    if (benefit.contains('movie')) return Icons.movie;
    if (benefit.contains('shopping')) return Icons.shopping_cart;
    return Icons.workspace_premium;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AnimatedBackground(
        child: SafeArea(
          child: Column(
            children: [
              // AppBar
              Padding(
                padding: const EdgeInsets.all(AppTheme.spacingM),
                child: Row(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.arrow_back),
                      onPressed: () => Navigator.pop(context),
                    ),
                    const Expanded(
                      child: Text(
                        'Top Recommendation',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    const SizedBox(width: 48),
                  ],
                ),
              ),

              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(AppTheme.spacingL),
                  child: Column(
                    children: [
                      const SizedBox(height: AppTheme.spacingL),

                      // Premium Badge
                      FadeInWidget(
                        delay: const Duration(milliseconds: 100),
                        child: AnimatedBuilder(
                          animation: _glowAnimation,
                          builder: (context, child) {
                            return Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: AppTheme.spacingL,
                                vertical: AppTheme.spacingS,
                              ),
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    AppTheme.accentTeal.withOpacity(_glowAnimation.value),
                                    AppTheme.primaryBlue.withOpacity(_glowAnimation.value),
                                  ],
                                ),
                                borderRadius: BorderRadius.circular(AppTheme.radiusXL),
                                boxShadow: [
                                  BoxShadow(
                                    color: AppTheme.accentTeal.withOpacity(0.4 * _glowAnimation.value),
                                    blurRadius: 15,
                                    offset: const Offset(0, 4),
                                  ),
                                ],
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: const [
                                  Icon(Icons.star_rounded, color: Colors.amber, size: 20),
                                  SizedBox(width: AppTheme.spacingS),
                                  Text(
                                    'BEST MATCH FOR YOU',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 1.2,
                                      fontSize: 12,
                                    ),
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                      ),

                      const SizedBox(height: AppTheme.spacingXL),

                      // Hero Card with Animated Glow
                      FadeInWidget(
                        delay: const Duration(milliseconds: 300),
                        child: AnimatedBuilder(
                          animation: _glowAnimation,
                          builder: (context, child) {
                            return Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(AppTheme.radiusXL),
                                boxShadow: [
                                  BoxShadow(
                                    color: AppTheme.primaryBlue.withOpacity(0.3 * _glowAnimation.value),
                                    blurRadius: 30,
                                    spreadRadius: 5,
                                    offset: const Offset(0, 10),
                                  ),
                                ],
                              ),
                              child: Container(
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [
                                      AppTheme.primaryBlue,
                                      AppTheme.primaryBlue.withOpacity(0.85),
                                    ],
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                  ),
                                  borderRadius: BorderRadius.circular(AppTheme.radiusXL),
                                ),
                                padding: const EdgeInsets.all(AppTheme.spacingXL),
                                child: Column(
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.all(AppTheme.spacingL),
                                      decoration: BoxDecoration(
                                        color: Colors.white.withOpacity(0.15),
                                        shape: BoxShape.circle,
                                        border: Border.all(
                                          color: Colors.white.withOpacity(0.3),
                                          width: 2,
                                        ),
                                      ),
                                      child: Icon(
                                        _getBenefitIcon(),
                                        size: 64,
                                        color: Colors.white,
                                      ),
                                    ),
                                    const SizedBox(height: AppTheme.spacingL),
                                    Text(
                                      _recommendedBenefit,
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontSize: 26,
                                        fontWeight: FontWeight.bold,
                                        height: 1.3,
                                      ),
                                      textAlign: TextAlign.center,
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                      ),

                      const SizedBox(height: AppTheme.spacingXL),

                      // Confidence Score
                      FadeInWidget(
                        delay: const Duration(milliseconds: 500),
                        child: Column(
                          children: [
                            ConfidenceScoreWidget(
                              score: _confidenceScore,
                              size: 120,
                              showLabel: true,
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: AppTheme.spacingXL),

                      // Why This Benefit Section
                      if (_reasoning.isNotEmpty)
                        FadeInWidget(
                          delay: const Duration(milliseconds: 600),
                          child: Card(
                            child: Padding(
                              padding: const EdgeInsets.all(AppTheme.spacingL),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Container(
                                        padding: const EdgeInsets.all(AppTheme.spacingS),
                                        decoration: BoxDecoration(
                                          color: AppTheme.primaryBlue.withOpacity(0.1),
                                          borderRadius: BorderRadius.circular(AppTheme.radiusM),
                                        ),
                                        child: const Icon(
                                          Icons.lightbulb_outline,
                                          color: AppTheme.primaryBlue,
                                          size: 20,
                                        ),
                                      ),
                                      const SizedBox(width: AppTheme.spacingM),
                                      Text(
                                        'Why This Benefit?',
                                        style: Theme.of(context).textTheme.titleLarge,
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: AppTheme.spacingL),
                                  ..._reasoning.asMap().entries.map((entry) {
                                    final index = entry.key;
                                    final reason = entry.value;
                                    return _buildReasonItem(
                                      index + 1,
                                      reason,
                                    );
                                  }).toList(),
                                ],
                              ),
                            ),
                          ),
                        ),

                      const SizedBox(height: AppTheme.spacingXL),

                      // User Profile Info
                      FadeInWidget(
                        delay: const Duration(milliseconds: 700),
                        child: Card(
                          child: Padding(
                            padding: const EdgeInsets.all(AppTheme.spacingL),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Matched Profile',
                                  style: Theme.of(context).textTheme.titleLarge,
                                ),
                                const SizedBox(height: AppTheme.spacingL),
                                _buildProfileItem(
                                  Icons.person_outline,
                                  'User Type',
                                  widget.userContext['user_type']?.toString() ?? 'N/A',
                                ),
                                const Divider(height: 24),
                                _buildProfileItem(
                                  Icons.location_on_outlined,
                                  'Location',
                                  widget.userContext['location']?.toString() ?? 'N/A',
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildReasonItem(int number, String reason) {
    return Padding(
      padding: const EdgeInsets.only(bottom: AppTheme.spacingM),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              gradient: AppTheme.primaryGradient,
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Text(
                '$number',
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                ),
              ),
            ),
          ),
          const SizedBox(width: AppTheme.spacingM),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Text(
                reason,
                style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                  height: 1.5,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProfileItem(IconData icon, String label, String value) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: AppTheme.accentTeal.withOpacity(0.1),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(icon, color: AppTheme.accentTeal, size: 20),
        ),
        const SizedBox(width: AppTheme.spacingM),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              Text(
                value,
                style: Theme.of(context).textTheme.titleMedium,
              ),
            ],
          ),
        ),
      ],
    );
  }
}

                                  'Personalized Match',
                                  'Perfect fit for ${widget.userContext['user_type']}s',
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),

                      const SizedBox(height: AppTheme.spacingXL),

                      // Action Buttons
                      FadeInWidget(
                        delay: const Duration(milliseconds: 700),
                        child: Column(
                          children: [
                            PrimaryButton(
                              text: 'Learn Why',
                              icon: Icons.lightbulb_outline,
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => WhyBenefitPage(
                                      aiResponse: widget.aiResponse,
                                      userContext: widget.userContext,
                                      recommendedBenefit: recommendedBenefit,
                                    ),
                                  ),
                                );
                              },
                            ),
                            const SizedBox(height: AppTheme.spacingM),
                            OutlinedButton(
                              onPressed: () {
                                // Navigate to all benefits - will implement next
                              },
                              child: const Text('See All Benefits'),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFeatureItem(IconData icon, String title, String description) {
    return Padding(
      padding: const EdgeInsets.only(bottom: AppTheme.spacingM),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(AppTheme.spacingS),
            decoration: BoxDecoration(
              color: AppTheme.accentTeal.withOpacity(0.1),
              borderRadius: BorderRadius.circular(AppTheme.radiusM),
            ),
            child: Icon(
              icon,
              color: AppTheme.accentTeal,
              size: 20,
            ),
          ),
          const SizedBox(width: AppTheme.spacingM),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                const SizedBox(height: 2),
                Text(
                  description,
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
