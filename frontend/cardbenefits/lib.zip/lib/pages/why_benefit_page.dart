import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/common_widgets.dart';
import '../widgets/animated_background.dart';
import 'all_benefits_page.dart';

class WhyBenefitPage extends StatelessWidget {
  final Map<String, dynamic> aiResponse;
  final Map<String, dynamic> userContext;
  final String recommendedBenefit;

  const WhyBenefitPage({
    super.key,
    required this.aiResponse,
    required this.userContext,
    required this.recommendedBenefit,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AnimatedBackground(
        child: SafeArea(
          child: Column(
            children: [
              // AppBar
              Padding(
                padding: const EdgeInsets.all(AppTheme.spacingM),
                child: Row(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.arrow_back),
                      onPressed: () => Navigator.pop(context),
                    ),
                    const Expanded(
                      child: Text(
                        'AI Reasoning',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    const SizedBox(width: 48),
                  ],
                ),
              ),

              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(AppTheme.spacingL),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Header
                      FadeInWidget(
                        delay: const Duration(milliseconds: 100),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Why We Recommend',
                              style: Theme.of(context).textTheme.displaySmall,
                            ),
                            const SizedBox(height: AppTheme.spacingS),
                            ShaderMask(
                              shaderCallback: (bounds) =>
                                  AppTheme.primaryGradient.createShader(bounds),
                              child: Text(
                                recommendedBenefit,
                                style: Theme.of(context)
                                    .textTheme
                                    .displayMedium
                                    ?.copyWith(
                                      color: Colors.white,
                                    ),
                              ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: AppTheme.spacingXL),

                      // User Context Section
                      FadeInWidget(
                        delay: const Duration(milliseconds: 200),
                        child: _buildSection(
                          context,
                          'Your Profile',
                          Icons.person,
                          AppTheme.primaryBlue,
                          [
                            _buildReasonCard(
                              context,
                              'User Type',
                              userContext['user_type'] ?? 'N/A',
                              'Your lifestyle and spending habits as a ${userContext['user_type']} align perfectly with this benefit.',
                              Icons.school,
                            ),
                            _buildReasonCard(
                              context,
                              'Location',
                              userContext['location'] ?? 'N/A',
                              'This benefit is widely accepted and provides maximum value in ${userContext['location']}.',
                              Icons.location_on,
                            ),
                            _buildReasonCard(
                              context,
                              'Language Preference',
                              userContext['language'] ?? 'N/A',
                              'Support and documentation available in your preferred language.',
                              Icons.language,
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: AppTheme.spacingXL),

                      // AI Analysis Section
                      FadeInWidget(
                        delay: const Duration(milliseconds: 400),
                        child: _buildSection(
                          context,
                          'AI Analysis',
                          Icons.psychology,
                          AppTheme.accentTeal,
                          [
                            _buildAnalysisCard(
                              context,
                              'Data-Driven Decision',
                              'Our AI analyzed hundreds of benefit scenarios and spending patterns to identify the best match for your profile.',
                              Icons.analytics,
                            ),
                            _buildAnalysisCard(
                              context,
                              'Personalization Engine',
                              'The recommendation considers your user type, location, and typical transaction patterns.',
                              Icons.tune,
                            ),
                            _buildAnalysisCard(
                              context,
                              'Maximum Value',
                              'Based on similar user profiles, this benefit typically provides 40% higher value compared to alternatives.',
                              Icons.trending_up,
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: AppTheme.spacingXL),

                      // RAG Transparency
                      FadeInWidget(
                        delay: const Duration(milliseconds: 600),
                        child: Card(
                          color: AppTheme.accentTeal.withOpacity(0.05),
                          child: Padding(
                            padding: const EdgeInsets.all(AppTheme.spacingL),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Icon(
                                      Icons.verified_user,
                                      color: AppTheme.accentTeal,
                                    ),
                                    const SizedBox(width: AppTheme.spacingM),
                                    Expanded(
                                      child: Text(
                                        'Transparent AI Process',
                                        style: Theme.of(context)
                                            .textTheme
                                            .titleLarge,
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: AppTheme.spacingM),
                                Text(
                                  'Our AI uses Retrieval-Augmented Generation (RAG) to ensure all recommendations are based on verified benefit data. No assumptions or hallucinations—only facts from our curated database.',
                                  style: Theme.of(context).textTheme.bodyLarge,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),

                      const SizedBox(height: AppTheme.spacingXXL),

                      // Action Button
                      FadeInWidget(
                        delay: const Duration(milliseconds: 800),
                        child: PrimaryButton(
                          text: 'Explore All Benefits',
                          icon: Icons.grid_view,
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => AllBenefitsPage(
                                  aiResponse: aiResponse,
                                  userContext: userContext,
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSection(
    BuildContext context,
    String title,
    IconData icon,
    Color color,
    List<Widget> children,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              padding: const EdgeInsets.all(AppTheme.spacingM),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(AppTheme.radiusM),
              ),
              child: Icon(icon, color: color, size: 24),
            ),
            const SizedBox(width: AppTheme.spacingM),
            Text(
              title,
              style: Theme.of(context).textTheme.headlineMedium,
            ),
          ],
        ),
        const SizedBox(height: AppTheme.spacingL),
        ...children,
      ],
    );
  }

  Widget _buildReasonCard(
    BuildContext context,
    String label,
    String value,
    String explanation,
    IconData icon,
  ) {
    return Card(
      margin: const EdgeInsets.only(bottom: AppTheme.spacingM),
      child: Padding(
        padding: const EdgeInsets.all(AppTheme.spacingL),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(AppTheme.spacingS),
              decoration: BoxDecoration(
                color: AppTheme.primaryBlue.withOpacity(0.1),
                borderRadius: BorderRadius.circular(AppTheme.radiusM),
              ),
              child: Icon(icon, color: AppTheme.primaryBlue, size: 20),
            ),
            const SizedBox(width: AppTheme.spacingM),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: Theme.of(context).textTheme.labelLarge?.copyWith(
                          color: AppTheme.textSecondary,
                        ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    value,
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                  const SizedBox(height: AppTheme.spacingS),
                  Text(
                    explanation,
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAnalysisCard(
    BuildContext context,
    String title,
    String description,
    IconData icon,
  ) {
    return Card(
      margin: const EdgeInsets.only(bottom: AppTheme.spacingM),
      child: Padding(
        padding: const EdgeInsets.all(AppTheme.spacingL),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(AppTheme.spacingS),
              decoration: BoxDecoration(
                color: AppTheme.accentTeal.withOpacity(0.1),
                borderRadius: BorderRadius.circular(AppTheme.radiusM),
              ),
              child: Icon(icon, color: AppTheme.accentTeal, size: 20),
            ),
            const SizedBox(width: AppTheme.spacingM),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                  const SizedBox(height: AppTheme.spacingS),
                  Text(
                    description,
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
