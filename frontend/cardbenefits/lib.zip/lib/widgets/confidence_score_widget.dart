import 'package:flutter/material.dart';
import 'dart:math' as math;
import '../theme/app_theme.dart';

/// Elite animated confidence score widget with circular progress
/// Displays AI confidence rating with smooth animations
class ConfidenceScoreWidget extends StatefulWidget {
  final double score; // 0.0 to 1.0
  final double size;
  final bool showLabel;

  const ConfidenceScoreWidget({
    super.key,
    required this.score,
    this.size = 120.0,
    this.showLabel = true,
  });

  @override
  State<ConfidenceScoreWidget> createState() => _ConfidenceScoreWidgetState();
}

class _ConfidenceScoreWidgetState extends State<ConfidenceScoreWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  late Animation<double> _glowAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );

    _animation = Tween<double>(
      begin: 0.0,
      end: widget.score,
    ).animate(CurvedAnimation(
      parent: _controller,
      curve: Curves.easeOutCubic,
    ));

    _glowAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _controller,
      curve: Curves.easeInOut,
    ));

    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Color _getScoreColor(double score) {
    if (score >= 0.8) return AppTheme.success;
    if (score >= 0.6) return AppTheme.accentTeal;
    if (score >= 0.4) return AppTheme.warning;
    return AppTheme.error;
  }

  String _getScoreLabel(double score) {
    if (score >= 0.8) return 'High Confidence';
    if (score >= 0.6) return 'Good Match';
    if (score >= 0.4) return 'Moderate';
    return 'Low Confidence';
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        AnimatedBuilder(
          animation: _animation,
          builder: (context, child) {
            final scoreColor = _getScoreColor(_animation.value);
            
            return Container(
              width: widget.size,
              height: widget.size,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: scoreColor.withOpacity(0.3 * _glowAnimation.value),
                    blurRadius: 20 * _glowAnimation.value,
                    spreadRadius: 5 * _glowAnimation.value,
                  ),
                ],
              ),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  // Background circle
                  SizedBox(
                    width: widget.size,
                    height: widget.size,
                    child: CircularProgressIndicator(
                      value: 1.0,
                      strokeWidth: 8,
                      color: Colors.grey.shade200,
                      backgroundColor: Colors.transparent,
                    ),
                  ),
                  
                  // Animated progress circle
                  SizedBox(
                    width: widget.size,
                    height: widget.size,
                    child: CircularProgressIndicator(
                      value: _animation.value,
                      strokeWidth: 8,
                      color: scoreColor,
                      backgroundColor: Colors.transparent,
                      strokeCap: StrokeCap.round,
                    ),
                  ),
                  
                  // Center content
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        '${(_animation.value * 100).toInt()}%',
                        style: TextStyle(
                          fontSize: widget.size * 0.25,
                          fontWeight: FontWeight.bold,
                          color: scoreColor,
                        ),
                      ),
                      if (widget.size > 100)
                        Text(
                          'Match',
                          style: TextStyle(
                            fontSize: widget.size * 0.12,
                            color: AppTheme.textSecondary,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                    ],
                  ),
                ],
              ),
            );
          },
        ),
        
        if (widget.showLabel) ...[
          const SizedBox(height: 12),
          AnimatedBuilder(
            animation: _animation,
            builder: (context, child) {
              return Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 8,
                ),
                decoration: BoxDecoration(
                  color: _getScoreColor(_animation.value).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: _getScoreColor(_animation.value).withOpacity(0.3),
                    width: 1,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.check_circle,
                      size: 16,
                      color: _getScoreColor(_animation.value),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      _getScoreLabel(_animation.value),
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: _getScoreColor(_animation.value),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ],
    );
  }
}


/// Compact confidence indicator for list items
class CompactConfidenceIndicator extends StatelessWidget {
  final double score;
  
  const CompactConfidenceIndicator({
    super.key,
    required this.score,
  });

  Color _getScoreColor(double score) {
    if (score >= 0.8) return AppTheme.success;
    if (score >= 0.6) return AppTheme.accentTeal;
    if (score >= 0.4) return AppTheme.warning;
    return AppTheme.error;
  }

  @override
  Widget build(BuildContext context) {
    final scoreColor = _getScoreColor(score);
    
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 40,
          height: 6,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(3),
            color: Colors.grey.shade200,
          ),
          child: FractionallySizedBox(
            alignment: Alignment.centerLeft,
            widthFactor: score,
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(3),
                color: scoreColor,
              ),
            ),
          ),
        ),
        const SizedBox(width: 6),
        Text(
          '${(score * 100).toInt()}%',
          style: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w600,
            color: scoreColor,
          ),
        ),
      ],
    );
  }
}
